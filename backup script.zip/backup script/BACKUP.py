import os, shutil#--------------needed
import datetime#------------Not needed

#---------[[date %y-%m-%d] - [time %H-%M]  This is only to set time in the name of the backup]

time = datetime.datetime.now()#----------Not needed!  just to show time

source = "C:\\Users\\PCname\\project\\important_files"#---------path to the folder you want to save to your backup

destination = "C:\\Users\\crill\\Documents\\backup\\"+ time.strftime("Backup [date %y-%m-%d] - [time %H-%M]")#--------------path to the folder you want to save your backup to

shutil.copytree(src=source, dst=destination)#----------copy the folder and everything inside it

#-----------Checking there is no duplicates
dir = os.path.join("C:\\Users\\PCname\\Documents\\backup\\"+ time.strftime("Backup [date %y-%m-%d] - [time %H-%M]"))#--------If the backup is made, then it will not be duplicated
if not os.path.exists(dir):
    os.mkdir(dir)

print("---------------------[backup successfully completed]---------------------")#-------------Just a nice message saying it's done


exit#-------------Done